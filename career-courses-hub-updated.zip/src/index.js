import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import CareerCoursesHub from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<CareerCoursesHub />);
