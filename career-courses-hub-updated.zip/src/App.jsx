import React, { useState } from "react";
import { Search } from "lucide-react";

export default function CareerCoursesHub() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");

  const courses = [
    { id: 1, title: "Frontend-разработчик с нуля", category: "it", duration: "4 месяца", level: "начальный", description: "Изучите HTML, CSS, JavaScript и React, чтобы начать карьеру веб-разработчика." },
    { id: 2, title: "UX/UI-дизайн: профессия будущего", category: "design", duration: "3 месяца", level: "начальный", description: "Освойте основы интерфейса и опыта. Научитесь работать с Figma." },
    { id: 3, title: "Digital-маркетолог", category: "marketing", duration: "5 месяцев", level: "средний", description: "Курс охватывает SEO, контекстную рекламу и аналитику." }
  ];

  const filtered = courses.filter(c =>
    (category === "all" || c.category === category) &&
    c.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <header className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800">Career Courses Hub</h1>
          <p className="text-slate-600">Курсы для роста и новых профессий</p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-60" size={16} />
          <input
            className="pl-9 pr-3 py-2 rounded-lg border focus:outline-none"
            placeholder="Поиск курса..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </header>

      <main className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        <aside className="bg-white p-4 rounded-2xl shadow-sm">
          <h2 className="font-semibold mb-3">Категории</h2>
          {["all", "it", "design", "marketing"].map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              className={\`block w-full text-left px-3 py-2 rounded-lg mb-1 \${category === cat ? "bg-green-100" : "hover:bg-gray-50"}\`}>
              {cat === "all" ? "Все направления" : cat.toUpperCase()}
            </button>
          ))}
        </aside>

        <section className="md:col-span-2 space-y-4">
          {filtered.map(c => (
            <div key={c.id} className="bg-white p-4 rounded-2xl shadow-sm">
              <h3 className="text-lg font-semibold">{c.title}</h3>
              <p className="text-sm text-gray-600 mb-2">Категория: {c.category}</p>
              <p className="text-sm mb-3">{c.description}</p>
              <div className="text-sm text-gray-500">⏱ {c.duration} • 📈 {c.level}</div>
            </div>
          ))}
        </section>
      </main>

      <footer className="max-w-5xl mx-auto mt-8 text-center text-gray-500 text-sm">
        © 2025 Career Courses Hub
      </footer>
    </div>
  );
}
